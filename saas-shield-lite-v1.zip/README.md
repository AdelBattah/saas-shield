# Solo Founder & SaaS Revenue Shield — Lite (MIT Open-Core Skills)

[![License: MIT](https://img.shields.io/badge/License-MIT-emerald.svg?style=flat-square)](LICENSE)
[![Interactive 10-Point Audit](https://img.shields.io/badge/Free_Checklist-Interactive_Web_Audit-38BDF8?style=flat-square)](https://adelbattah.github.io/checklist.html?utm_source=github&utm_medium=readme)
[![Pro 4-Skill Bundle](https://img.shields.io/badge/Full_Pro_Bundle-$39_(Save_$40.96)-F59E0B?style=flat-square)](https://adelbattah.github.io/#pricing?utm_source=github&utm_medium=readme)

**4 free, MIT-licensed `SKILL.md` auditor skills** for **Claude Code, Cursor, Antigravity, and ChatGPT** that catch the highest-cost founder mistakes before they hit production: AWS bill shocks, Stripe double-fulfillment bugs, predatory client contracts, and ghosting invoices.

---

## 30-Second Quickstart

### Install via `skills` CLI (Claude Code / Cursor / Agents)
```bash
npx skills add AdelBattah/saas-revenue-shield-lite
```

### Or Install Manually (Zero Dependencies)
```bash
git clone https://github.com/AdelBattah/saas-revenue-shield-lite.git
cp -R saas-revenue-shield-lite/skills/* ~/.claude/skills/
```

### Cursor Rules (`.cursor/rules/`)
Copy any file from `.cursor/rules/` directly into your project's `.cursor/rules/` directory.

---

## Included Free Lite Skills (`skills/`)

| Skill | Trigger Prompt Example | What It Catches (Free MIT Lite) |
| :--- | :--- | :--- |
| **`aws-bill-shock-check-lite`** | *"Audit this Terraform file for AWS bill traps"* | NAT Gateway S3 bleeds, unthrottled Lambda loops, public S3 exposure, missing AWS Budgets |
| **`stripe-webhook-audit-lite`** | *"Audit my `/api/webhooks/stripe` handler"* | Parsed-JSON signature bugs, missing `event.id` idempotency, >2s timeout retry storms |
| **`contract-redline-lite`** | *"Scan this client SOW for IP & liability traps"* | Missing pre-existing IP carve-outs, delivery-vs-payment IP transfer, uncapped liability, infinite revisions |
| **`invoice-escalation-lite`** | *"Draft a Day-20 escalation for unpaid Invoice #104"* | Classifies overdue tier (Day 1–45+) & replaces weak "gentle reminders" with firm commercial deadlines |

---

## Free MIT Lite vs. Full Pro Bundle (`$29` / `$39` One-Time)

The MIT Lite skills in this repo are **genuinely useful standalone pre-flight scanners**. Upgrade to the **Full Pro Bundle** when you want drop-in production code, legal counter-clauses, and emergency incident playbooks:

| Capability | Free Lite (This Repo — MIT) | **Full Pro Bundle (`$39` One-Time)** |
| :--- | :---: | :---: |
| Core Risk Detection & Audit Tables | ✅ | ✅ |
| Drop-in Terraform IAM Region/GPU Locks & IMDSv2 Rules | — | ✅ |
| Guided 15-Min AWS Breach Runbook + Support Credit Appeal | — | ✅ |
| Drop-in Hardened Stripe Code (Next.js, Express, FastAPI) + SQL | — | ✅ |
| Drop-in Legal Counter-Clauses + Diplomatic Redline Email | — | ✅ |
| 4-Tier Debt Ladder + US/UK/EU Interest Math + IP Revocation Notice | — | ✅ |
| 1-Command Windows (`install.ps1`) & Mac/Linux (`install.sh`) Installer | — | ✅ |

- **Try the Free Interactive 10-Point Web Audit:** https://adelbattah.github.io/checklist.html?utm_source=github&utm_medium=readme
- **Get the Full 4-Skill Pro Bundle (\$39 vs. \$79.96 retail, 14-day guarantee):** https://adelbattah.github.io/#pricing?utm_source=github&utm_medium=readme
